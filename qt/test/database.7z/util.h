#ifndef UTIL_H
#define UTIL_H

#define DATABASE_PATH "D:/DATABASETEST/Database.db"

#endif // UTIL_H
