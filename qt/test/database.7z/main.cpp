#include "mainwindow.h"
#include <QApplication>
#include "database.h"
#include "countrywindow.h"
#include "brandwindow.h"
#include "sizewindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    Database db;
    CountryWindow cw;
    cw.show();
    BrandWindow bw;
    bw.show();
    SizeWindow sw;
    sw.show();
    return a.exec();
}
