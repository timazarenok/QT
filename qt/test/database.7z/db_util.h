#ifndef DB_UTIL_H
#define DB_UTIL_H
#include <QSqlQuery>
#include <QDebug>
#include <QSqlError>





#endif // DB_UTIL_H
